ACL = ('public-read', 'private', 'public-read-write')

TRANSFER_MODES = ('auto', 'sync', 'single-part-upload')

